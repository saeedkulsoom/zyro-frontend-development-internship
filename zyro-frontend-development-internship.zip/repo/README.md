# Zyro Frontend Development Internship

This repository contains my submissions for the **Zyroo Frontend Development Internship**.

- **Intern:** Kulsoom Saeed
- **Portfolio:** [saeedkulsoom.github.io](https://saeedkulsoom.github.io/)
- **GitHub:** [@saeedkulsoom](https://github.com/saeedkulsoom)

## Structure

```
zyro-frontend-development-internship/
├── week-01/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── evidence/
├── week-04/
│   └── manzil-tracking.html
├── week-05/
│   ├── index.html
│   ├── .env.example
│   ├── css/
│   └── js/
│       ├── api/
│       ├── services/
│       ├── store/
│       ├── realtime/
│       ├── utils/
│       ├── components/
│       └── pages/
├── README.md
└── .gitignore
```

## Week 1 — Onboarding & Environment Setup

**Objective:** Set up the frontend development environment, configure Git and GitHub, and build a basic HTML/CSS/JavaScript test page to verify everything works end-to-end.

**What's inside `week-01/`:**
- `index.html` — a personal introduction page (heading, bio, skills, contact links)
- `style.css` — styling, applied and responsive across desktop and mobile
- `script.js` — JavaScript interaction (rotating status line + email button)
- `evidence/` — screenshots proving environment setup:
  - Node.js / npm version
  - Git version
  - Working webpage in browser
  - Developer Tools / console with no major errors
  - Proof of joining the Zyroo WhatsApp Community and Channel

**How to run it:**
1. Clone this repository
2. Open `week-01/index.html` in a browser (no build step required)

## Week 4 — Delivery Tracking & Notifications

**What's inside `week-04/`:** `manzil-tracking.html` — a single-page tracking screen with a simulated map/route (pickup, rider, delivery), rider info, estimated delivery, status timeline, a notification bell with badge, and search/filters for the orders list. See `week-04/README.md` for the full feature list.

## Week 5 — Advanced Platform Integration & Real-Time Operations

**Objective:** Move beyond static screens into a realistic application architecture — API integration, a central service layer, shared state management, role-based protected actions, simulated real-time delivery updates, optimistic UI, advanced search/filtering, pagination, and loading/error/retry handling.

**What's inside `week-05/`:** a reorganized vanilla-JS SPA (`components/`, `pages/`, `services/`, `store/`, `realtime/`, `utils/`, `api/`), a mock REST API with simulated latency and failures, a central `apiService.js`, a small pub/sub store, role-based demo accounts (business / rider / customer), and a simulated real-time engine that advances deliveries live on the tracking screen. Full details in `week-05/README.md`.

**How to run it:**
1. `cd week-05`
2. Serve the folder (`npx serve .` or `python3 -m http.server`) and open it in a browser
3. Sign in as one of the three demo accounts to see role-based behavior

## Tools Used

HTML5, CSS3, JavaScript (ES modules), Git, GitHub, Node.js, npm, VS Code, Google Chrome DevTools.
