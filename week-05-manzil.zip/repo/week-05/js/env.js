// env.js — stands in for a .env file in this no-build-step vanilla project.
// In a bundler setup (Vite/CRA/Next) these would be real environment variables
// (import.meta.env.VITE_API_BASE_URL / process.env.REACT_APP_API_BASE_URL) and
// this file would not exist / would not be committed. See .env.example.
window.__ENV__ = {
  API_BASE_URL: "/api",       // base path the service layer targets (mocked in-browser)
  MOCK_DELAY_MS: 700,         // simulated network latency
  MOCK_SLOW_MS: 1500,         // requests slower than this trigger a "still loading" hint
  MOCK_FAILURE_RATE: 0.12,    // ~12% of mock requests randomly fail, to exercise error/retry UI
  REALTIME_INTERVAL_MS: 4500  // how often the simulated real-time engine ticks
};
