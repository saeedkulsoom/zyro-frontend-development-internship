import { store, permissions } from "../store/store.js";
import { updateDeliveryStatus, acceptDelivery, cancelOrder } from "../store/actions.js";
import { STATUS_META, STATUS_ORDER, timeAgo } from "../utils/format.js";
import { emptyState, unauthorizedState } from "../components/states.js";

function routeSVG(o) {
  const pts = [
    { x: 60, y: 110, label: o.pickup, color: "var(--blue)" },
    { x: 270, y: 50, label: o.riderPos || "—", color: "var(--amber)" },
    { x: 480, y: 110, label: o.delivery, color: "var(--green)" }
  ];
  return `<svg viewBox="0 0 540 170" xmlns="http://www.w3.org/2000/svg">
    <path d="M60,110 Q165,20 270,50 T480,110" fill="none" stroke="#26394F" stroke-width="3" stroke-dasharray="1 10" stroke-linecap="round"/>
    <path d="M60,110 Q165,20 270,50" fill="none" stroke="#4FC3F7" stroke-width="3" stroke-linecap="round"/>
    ${pts.map((p) => `
      <circle cx="${p.x}" cy="${p.y}" r="9" fill="${p.color}"/>
      <text x="${p.x}" y="${p.y + 30}" text-anchor="middle" fill="#E7EDF4" font-family="Inter" font-size="13" font-weight="500">${p.label}</text>
    `).join("")}
  </svg>`;
}

export function renderTracking(orderId) {
  const s = store.getState();
  const order = s.orders.find((o) => o.id === orderId);
  const el = document.createElement("div");
  el.className = "page track";

  if (!order) {
    el.appendChild(emptyState("That order couldn't be found."));
    return el;
  }

  if (s.userRole === "customer" && order.customer !== s.authenticatedUser.name) {
    el.appendChild(unauthorizedState("You can only track your own orders."));
    return el;
  }
  if (s.userRole === "rider" && order.riderId !== s.authenticatedUser.id) {
    el.appendChild(unauthorizedState("This delivery isn't assigned to you."));
    return el;
  }

  const meta = STATUS_META[order.status] || { label: order.status, cls: "pending" };
  const rider = s.riders.find((r) => r.id === order.riderId);
  const isRider = permissions.canUpdateDeliveryStatus(s.userRole) && order.riderId === s.authenticatedUser?.id;
  const isBusiness = permissions.canCancelOrder(s.userRole);
  const nextStatusIdx = STATUS_ORDER.indexOf(order.status) + 1;
  const nextStatus = STATUS_ORDER[nextStatusIdx];

  el.innerHTML = `
    <div class="track-head">
      <div><h1>${order.id}</h1><div class="sub">${order.customer} · placed ${order.date}</div></div>
      <div class="eta-box"><div class="label">estimated delivery</div><div class="val">${order.eta || "—"}</div></div>
    </div>
    <div class="status-line">
      <span class="pill ${meta.cls}">${meta.label}</span>
      <span class="sub">${order.pickup} → ${order.delivery}</span>
      <span class="sub last-updated">Last updated ${timeAgo(order.lastUpdated)}</span>
    </div>
    <div class="map">${routeSVG(order)}</div>
    <div class="grid2">
      <div class="card">
        <h3>Rider</h3>
        ${rider ? `
          <div class="rider"><div class="avatar">${rider.name.split(" ").map((w) => w[0]).join("")}</div>
          <div><div class="name">${rider.name}</div><div class="veh">${rider.vehicle}</div></div></div>
          <div class="rider-detail"><span>Phone</span><span>${rider.phone}</span></div>
        ` : `<p class="sub">No rider assigned yet.</p>`}
        ${isRider && order.status !== "delivered" && order.status !== "cancelled" ? `
          <div class="form-actions">
            ${order.status === "pending" ? `<button class="btn" id="acceptBtn">Accept delivery</button>` : ""}
            ${nextStatus && order.status !== "pending" ? `<button class="btn" id="advanceBtn">Mark as ${STATUS_META[nextStatus].label}</button>` : ""}
          </div>` : ""}
        ${isBusiness && order.status !== "delivered" && order.status !== "cancelled" ? `
          <div class="form-actions"><button class="btn ghost" id="cancelBtn">Cancel order</button></div>` : ""}
      </div>
      <div class="card">
        <h3>Delivery timeline</h3>
        <ul class="timeline">
          ${STATUS_ORDER.map((st) => {
            const idx = STATUS_ORDER.indexOf(st);
            const curIdx = STATUS_ORDER.indexOf(order.status);
            const state = order.status === "cancelled" ? "" : idx < curIdx ? "done" : idx === curIdx ? "current" : "";
            return `<li class="${state}"><div class="tl-dot"></div><div class="tl-title">${STATUS_META[st].label}</div></li>`;
          }).join("")}
        </ul>
      </div>
    </div>
  `;

  const acceptBtn = el.querySelector("#acceptBtn");
  if (acceptBtn) acceptBtn.addEventListener("click", () => acceptDelivery(order.id));
  const advanceBtn = el.querySelector("#advanceBtn");
  if (advanceBtn && nextStatus) advanceBtn.addEventListener("click", () => updateDeliveryStatus(order.id, nextStatus));
  const cancelBtn = el.querySelector("#cancelBtn");
  if (cancelBtn) cancelBtn.addEventListener("click", () => cancelOrder(order.id));

  return el;
}
