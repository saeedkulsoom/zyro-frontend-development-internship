import { store, selectors, permissions } from "../store/store.js";
import { setFilters, clearFilters, goToPage, loadOrders, createOrder, assignRider, acceptDelivery, openOrder } from "../store/actions.js";
import { validateNewOrder } from "../utils/validation.js";
import { renderOrderCard } from "../components/orderCard.js";
import { renderPagination } from "../components/pagination.js";
import { loadingState, errorState, emptyState } from "../components/states.js";

export function renderDashboard() {
  const s = store.getState();
  const el = document.createElement("div");
  el.className = "page dashboard";

  if (s.loading.orders && !s.orders.length) {
    el.appendChild(loadingState(s.slow.orders));
    return el;
  }
  if (s.errors.orders) {
    el.appendChild(errorState(s.errors.orders, loadOrders));
    return el;
  }

  const canCreate = permissions.canCreateOrder(s.userRole);
  const { items, total } = selectors.paginated(s);
  const riders = s.riders;

  el.innerHTML = `
    <div class="dash-head">
      <h1>Orders</h1>
      ${canCreate ? `<button class="btn" id="newOrderBtn">New order</button>` : ""}
    </div>

    ${canCreate ? `
    <form id="newOrderForm" class="card new-order-form hidden">
      <div class="grid3">
        <div><label>Customer</label><input name="customer" placeholder="Customer name"></div>
        <div><label>Pickup</label><input name="pickup" placeholder="Pickup location"></div>
        <div><label>Delivery</label><input name="delivery" placeholder="Delivery location"></div>
      </div>
      <div class="form-errors"></div>
      <div class="form-actions"><button type="submit" class="btn">Create order</button></div>
    </form>` : ""}

    <div class="filters-bar">
      <input id="searchInput" class="search-input" placeholder="Search Order ID or customer" value="${s.filters.query}">
      <select id="statusFilter">
        <option value="">All statuses</option>
        <option value="pending">Pending pickup</option>
        <option value="accepted">Accepted</option>
        <option value="picked">Picked up</option>
        <option value="transit">In transit</option>
        <option value="delivered">Delivered</option>
      </select>
      <select id="riderFilter">
        <option value="">All riders</option>
        ${riders.map((r) => `<option value="${r.id}">${r.name}</option>`).join("")}
      </select>
      <input id="dateFilter" type="date" value="${s.filters.date}">
      <button class="btn ghost" id="clearFiltersBtn">Clear filters</button>
    </div>

    <div id="listSlot"></div>
    <div id="pagerSlot"></div>
  `;

  // Filters wiring
  el.querySelector("#searchInput").addEventListener("input", (e) => setFilters({ query: e.target.value }));
  el.querySelector("#statusFilter").value = s.filters.status;
  el.querySelector("#statusFilter").addEventListener("change", (e) => setFilters({ status: e.target.value }));
  el.querySelector("#riderFilter").value = s.filters.rider;
  el.querySelector("#riderFilter").addEventListener("change", (e) => setFilters({ rider: e.target.value }));
  el.querySelector("#dateFilter").addEventListener("change", (e) => setFilters({ date: e.target.value }));
  el.querySelector("#clearFiltersBtn").addEventListener("click", clearFilters);

  // New order form
  if (canCreate) {
    const toggleBtn = el.querySelector("#newOrderBtn");
    const form = el.querySelector("#newOrderForm");
    toggleBtn.addEventListener("click", () => form.classList.toggle("hidden"));
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const { valid, errors } = validateNewOrder(data);
      const errBox = form.querySelector(".form-errors");
      if (!valid) {
        errBox.innerHTML = Object.values(errors).map((m) => `<div class="inline-error">${m}</div>`).join("");
        return;
      }
      errBox.innerHTML = "";
      await createOrder(data);
      form.reset();
      form.classList.add("hidden");
    });
  }

  // List + pagination
  const listSlot = el.querySelector("#listSlot");
  if (!items.length) {
    listSlot.appendChild(emptyState("No orders match your search or filters."));
  } else {
    items.forEach((order) => {
      const card = renderOrderCard(order, { onOpen: openOrder });
      if (permissions.canAssignRider(s.userRole) && !order.riderId) {
        const assignRow = document.createElement("div");
        assignRow.className = "card-action";
        assignRow.innerHTML = `<select><option value="">Assign rider…</option>${riders.map((r) => `<option value="${r.id}">${r.name}</option>`).join("")}</select>`;
        assignRow.querySelector("select").addEventListener("change", (e) => {
          e.stopPropagation();
          if (e.target.value) assignRider(order.id, e.target.value);
        });
        assignRow.addEventListener("click", (e) => e.stopPropagation());
        card.appendChild(assignRow);
      }
      if (permissions.canAcceptDelivery(s.userRole) && order.riderId === s.authenticatedUser?.id && order.status === "pending") {
        const btn = document.createElement("button");
        btn.className = "btn ghost card-action";
        btn.textContent = "Accept delivery";
        btn.addEventListener("click", (e) => { e.stopPropagation(); acceptDelivery(order.id); });
        card.appendChild(btn);
      }
      listSlot.appendChild(card);
    });
  }
  el.querySelector("#pagerSlot").appendChild(renderPagination({ page: s.page, pageSize: s.pageSize, total }, goToPage));

  return el;
}
