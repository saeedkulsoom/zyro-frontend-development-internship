import { login } from "../store/actions.js";
import { validateLoginName } from "../utils/validation.js";
import { store } from "../store/store.js";

const DEMO_USERS = [
  { name: "Ayesha Noor", role: "business", desc: "create, edit, assign, cancel orders" },
  { name: "Bilal Khan", role: "rider", desc: "accept & update assigned deliveries" },
  { name: "Hina Yousaf", role: "customer", desc: "view & track own orders" }
];

export function renderAuthPage() {
  const el = document.createElement("div");
  el.className = "auth-page";
  const err = store.getState().errors.action;
  el.innerHTML = `
    <div class="auth-card">
      <h1>Manzil</h1>
      <p class="sub">Sign in as one of the demo accounts to see role-based access in action.</p>
      ${err ? `<div class="inline-error">${err}</div>` : ""}
      <div class="demo-users">
        ${DEMO_USERS.map((u) => `
          <button class="demo-user" data-name="${u.name}">
            <div class="name">${u.name}</div>
            <div class="role">${u.role}</div>
            <div class="desc">${u.desc}</div>
          </button>`).join("")}
      </div>
    </div>
  `;
  el.querySelectorAll(".demo-user").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const { valid, error } = validateLoginName(btn.dataset.name);
      if (!valid) return alert(error);
      try {
        await login(btn.dataset.name);
        location.hash = "#/dashboard";
      } catch (e) {
        // error is already surfaced via store.errors.action + re-render
      }
    });
  });
  return el;
}
