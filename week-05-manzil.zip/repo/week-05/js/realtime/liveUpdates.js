// liveUpdates.js — task requirement #6/#7: real-time (or realistic simulated
// real-time) delivery updates, connected to the store so any subscribed page
// (tracking, dashboard, notification bell) updates without a full refresh.
//
// A real deployment would replace `tick()` with a WebSocket `onmessage`
// handler or an SSE `EventSource` listener that dispatches the same store
// updates — the rest of the app would not need to change.
import { mockApi } from "../api/mockApi.js";
import { store } from "../store/store.js";

let timer = null;

function tick() {
  const result = mockApi._advanceRandomOrder();
  if (!result) return;
  const { order, notification } = result;
  store.setState((s) => ({
    orders: s.orders.map((o) => (o.id === order.id ? order : o)),
    notifications: [notification, ...s.notifications]
  }));
}

export function startLiveUpdates(intervalMs) {
  stopLiveUpdates();
  timer = setInterval(tick, intervalMs);
}

export function stopLiveUpdates() {
  if (timer) clearInterval(timer);
  timer = null;
}
