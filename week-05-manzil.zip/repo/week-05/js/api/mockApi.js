// mockApi.js — a suitable mock API per the task brief. Simulates a REST backend:
// network delay, occasional random failures, and a small in-memory database.
// Nothing here knows about UI/state — services/apiService.js is the only caller.
import { config } from "../config.js";

const STATUS_FLOW = ["pending", "accepted", "picked", "transit", "delivered"];

let db = {
  users: [
    { id: "u1", name: "Ayesha Noor", role: "business" },
    { id: "u2", name: "Bilal Khan", role: "rider" },
    { id: "u3", name: "Hina Yousaf", role: "customer" }
  ],
  riders: [
    { id: "u2", name: "Bilal Khan", phone: "+92 333 1122334", vehicle: "Honda CD 70 · Bike · PK-4521" },
    { id: "r2", name: "Junaid Iqbal", phone: "+92 300 4455667", vehicle: "Suzuki Alto · Car · PK-2290" }
  ],
  orders: [
    { id: "ORD-1042", customer: "Hina Yousaf", pickup: "Mardan", delivery: "Timergara", riderPos: "Chakdara", riderId: "u2", status: "transit", date: "2026-09-25", eta: "25 minutes", lastUpdated: Date.now() },
    { id: "ORD-1041", customer: "Adeel Raza", pickup: "Swabi", delivery: "Mardan", riderPos: "Swabi", riderId: "r2", status: "pending", date: "2026-09-25", eta: "55 minutes", lastUpdated: Date.now() },
    { id: "ORD-1039", customer: "Sana Tariq", pickup: "Chakdara", delivery: "Dir", riderPos: "Dir", riderId: null, status: "delivered", date: "2026-09-24", eta: "Delivered", lastUpdated: Date.now() },
    { id: "ORD-1038", customer: "Hina Yousaf", pickup: "Mardan", delivery: "Takht Bhai", riderPos: "Mardan", riderId: "u2", status: "picked", date: "2026-09-24", eta: "40 minutes", lastUpdated: Date.now() }
  ],
  notifications: [
    { id: "n1", text: "ORD-1041 — rider Junaid Iqbal assigned", time: Date.now() - 2 * 60000, read: false },
    { id: "n2", text: "ORD-1042 — delivery started from Chakdara", time: Date.now() - 18 * 60000, read: false },
    { id: "n3", text: "ORD-1038 — order picked up in Mardan", time: Date.now() - 60 * 60000, read: true }
  ],
  nextOrderSeq: 1043
};

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

function maybeFail(label) {
  if (Math.random() < config.mockFailureRate) {
    throw new Error(`${label} failed — the mock network dropped this request. Try again.`);
  }
}

async function call(label, fn) {
  await delay(config.mockDelayMs + Math.random() * 400);
  maybeFail(label);
  return fn();
}

export const mockApi = {
  login: (name) =>
    call("Login", () => {
      const user = db.users.find((u) => u.name.toLowerCase() === name.toLowerCase());
      if (!user) throw new Error("No account matches that name. Try Ayesha Noor, Bilal Khan, or Hina Yousaf.");
      return { ...user };
    }),

  getOrders: () => call("Get orders", () => db.orders.map((o) => ({ ...o }))),

  createOrder: (payload) =>
    call("Create order", () => {
      const id = `ORD-${db.nextOrderSeq++}`;
      const order = {
        id,
        customer: payload.customer,
        pickup: payload.pickup,
        delivery: payload.delivery,
        riderPos: payload.pickup,
        riderId: null,
        status: "pending",
        date: new Date().toISOString().slice(0, 10),
        eta: "—",
        lastUpdated: Date.now()
      };
      db.orders.unshift(order);
      db.notifications.unshift({ id: `n${Date.now()}`, text: `${id} — new order created`, time: Date.now(), read: false });
      return { ...order };
    }),

  updateOrder: (id, patch) =>
    call("Update order", () => {
      const order = db.orders.find((o) => o.id === id);
      if (!order) throw new Error(`${id} not found`);
      Object.assign(order, patch, { lastUpdated: Date.now() });
      return { ...order };
    }),

  assignRider: (id, riderId) =>
    call("Assign rider", () => {
      const order = db.orders.find((o) => o.id === id);
      if (!order) throw new Error(`${id} not found`);
      order.riderId = riderId;
      order.lastUpdated = Date.now();
      db.notifications.unshift({ id: `n${Date.now()}`, text: `${id} — rider assigned`, time: Date.now(), read: false });
      return { ...order };
    }),

  updateDeliveryStatus: (id, status) =>
    call("Update delivery status", () => {
      const order = db.orders.find((o) => o.id === id);
      if (!order) throw new Error(`${id} not found`);
      order.status = status;
      order.lastUpdated = Date.now();
      const labels = { accepted: "delivery accepted", picked: "order picked up", transit: "delivery started", delivered: "delivery completed" };
      db.notifications.unshift({ id: `n${Date.now()}`, text: `${id} — ${labels[status] || status}`, time: Date.now(), read: false });
      return { ...order };
    }),

  getNotifications: () => call("Get notifications", () => db.notifications.map((n) => ({ ...n }))),

  markNotificationRead: (id) =>
    call("Mark notification read", () => {
      const n = db.notifications.find((x) => x.id === id);
      if (n) n.read = true;
      return { ...n };
    }),

  getRiders: () => call("Get riders", () => db.riders.map((r) => ({ ...r }))),

  // Used by the simulated real-time engine to advance a random active order.
  _advanceRandomOrder: () => {
    const active = db.orders.filter((o) => o.status !== "delivered");
    if (!active.length) return null;
    const order = active[Math.floor(Math.random() * active.length)];
    const idx = STATUS_FLOW.indexOf(order.status);
    if (idx < STATUS_FLOW.length - 1) {
      order.status = STATUS_FLOW[idx + 1];
      order.lastUpdated = Date.now();
      const labels = { accepted: "delivery accepted", picked: "order picked up", transit: "delivery started", delivered: "delivery completed" };
      const note = { id: `n${Date.now()}`, text: `${order.id} — ${labels[order.status] || order.status}`, time: Date.now(), read: false };
      db.notifications.unshift(note);
      return { order: { ...order }, notification: note };
    }
    return null;
  }
};
