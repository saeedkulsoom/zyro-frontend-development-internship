// validation.js — reusable validation for forms and actions (task requirement #14).
export function validateNewOrder({ customer, pickup, delivery }) {
  const errors = {};
  if (!customer || !customer.trim()) errors.customer = "Customer name is required.";
  if (!pickup || !pickup.trim()) errors.pickup = "Pickup location is required.";
  if (!delivery || !delivery.trim()) errors.delivery = "Delivery location is required.";
  if (pickup && delivery && pickup.trim().toLowerCase() === delivery.trim().toLowerCase()) {
    errors.delivery = "Delivery location must differ from pickup.";
  }
  return { valid: Object.keys(errors).length === 0, errors };
}

export function validateLoginName(name) {
  if (!name || !name.trim()) return { valid: false, error: "Enter a name to continue." };
  return { valid: true };
}
