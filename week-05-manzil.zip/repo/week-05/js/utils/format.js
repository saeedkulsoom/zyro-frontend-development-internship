export function timeAgo(ts) {
  const mins = Math.round((Date.now() - ts) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  return `${hrs} hr ago`;
}

export const STATUS_META = {
  pending: { label: "Pending pickup", cls: "pending" },
  accepted: { label: "Accepted", cls: "picked" },
  picked: { label: "Picked up", cls: "picked" },
  transit: { label: "In transit", cls: "transit" },
  delivered: { label: "Delivered", cls: "delivered" },
  cancelled: { label: "Cancelled", cls: "pending" }
};

export const STATUS_ORDER = ["pending", "accepted", "picked", "transit", "delivered"];
