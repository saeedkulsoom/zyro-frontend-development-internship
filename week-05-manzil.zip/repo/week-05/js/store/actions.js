// actions.js — every place the app touches the API goes through here, so
// loading/error/slow-request handling and optimistic updates live in one spot.
import { apiService } from "../services/apiService.js";
import { store } from "./store.js";
import { config } from "../config.js";

function withSlowFlag(key, promise) {
  const timer = setTimeout(() => store.setState((s) => ({ slow: { ...s.slow, [key]: true } })), config.mockSlowMs);
  return promise.finally(() => {
    clearTimeout(timer);
    store.setState((s) => ({ slow: { ...s.slow, [key]: false } }));
  });
}

export async function login(name) {
  store.setState((s) => ({ loading: { ...s.loading, action: true }, errors: { ...s.errors, action: null } }));
  try {
    const user = await apiService.login(name);
    store.setState({ authenticatedUser: user, userRole: user.role, loading: { ...store.getState().loading, action: false } });
    await Promise.all([loadOrders(), loadNotifications(), loadRiders()]);
    return user;
  } catch (err) {
    store.setState((s) => ({ loading: { ...s.loading, action: false }, errors: { ...s.errors, action: err.message } }));
    throw err;
  }
}

export function logout() {
  store.setState({ authenticatedUser: null, userRole: null, orders: [], notifications: [], activeOrderId: null });
}

export async function loadOrders() {
  store.setState((s) => ({ loading: { ...s.loading, orders: true }, errors: { ...s.errors, orders: null } }));
  try {
    const orders = await withSlowFlag("orders", apiService.getOrders());
    store.setState((s) => ({ orders, loading: { ...s.loading, orders: false } }));
  } catch (err) {
    store.setState((s) => ({ loading: { ...s.loading, orders: false }, errors: { ...s.errors, orders: err.message } }));
  }
}

export async function loadNotifications() {
  store.setState((s) => ({ loading: { ...s.loading, notifications: true } }));
  try {
    const notifications = await apiService.getNotifications();
    store.setState((s) => ({ notifications, loading: { ...s.loading, notifications: false } }));
  } catch (err) {
    store.setState((s) => ({ loading: { ...s.loading, notifications: false }, errors: { ...s.errors, notifications: err.message } }));
  }
}

export async function loadRiders() {
  const riders = await apiService.getRiders().catch(() => []);
  store.setState({ riders });
}

export async function createOrder(payload) {
  store.setState((s) => ({ loading: { ...s.loading, action: true }, errors: { ...s.errors, action: null } }));
  try {
    const order = await apiService.createOrder(payload);
    store.setState((s) => ({ orders: [order, ...s.orders], loading: { ...s.loading, action: false } }));
    loadNotifications();
    return order;
  } catch (err) {
    store.setState((s) => ({ loading: { ...s.loading, action: false }, errors: { ...s.errors, action: err.message } }));
    throw err;
  }
}

export async function assignRider(orderId, riderId) {
  const before = store.getState().orders;
  store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? { ...o, riderId } : o)) })); // optimistic
  try {
    const updated = await apiService.assignRider(orderId, riderId);
    store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? updated : o)) }));
    loadNotifications();
  } catch (err) {
    store.setState({ orders: before, errors: { ...store.getState().errors, action: err.message } }); // rollback
  }
}

// Optimistic UI: accept delivery (rider role)
export async function acceptDelivery(orderId) {
  const before = store.getState().orders;
  store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? { ...o, status: "accepted" } : o)) }));
  try {
    const updated = await apiService.updateDeliveryStatus(orderId, "accepted");
    store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? updated : o)) }));
    loadNotifications();
  } catch (err) {
    store.setState({ orders: before, errors: { ...store.getState().errors, action: err.message } });
  }
}

// Optimistic UI: update delivery status (rider role)
export async function updateDeliveryStatus(orderId, status) {
  const before = store.getState().orders;
  store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? { ...o, status } : o)) }));
  try {
    const updated = await apiService.updateDeliveryStatus(orderId, status);
    store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? updated : o)) }));
    loadNotifications();
  } catch (err) {
    store.setState({ orders: before, errors: { ...store.getState().errors, action: err.message } });
  }
}

// Optimistic UI: mark notification as read
export async function markNotificationRead(id) {
  const before = store.getState().notifications;
  store.setState((s) => ({ notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) }));
  try {
    await apiService.markNotificationRead(id);
  } catch (err) {
    store.setState({ notifications: before, errors: { ...store.getState().errors, action: err.message } });
  }
}

export async function cancelOrder(orderId) {
  const before = store.getState().orders;
  store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? { ...o, status: "cancelled" } : o)) })); // optimistic
  try {
    const updated = await apiService.updateOrder(orderId, { status: "cancelled" });
    store.setState((s) => ({ orders: s.orders.map((o) => (o.id === orderId ? updated : o)) }));
  } catch (err) {
    store.setState({ orders: before, errors: { ...store.getState().errors, action: err.message } }); // rollback
  }
}

export function setFilters(patch) {
  store.setState((s) => ({ filters: { ...s.filters, ...patch }, page: 1 }));
}

export function clearFilters() {
  store.setState({ filters: { query: "", status: "", rider: "", date: "" }, page: 1 });
}

export function goToPage(page) {
  store.setState({ page });
}

export function openOrder(orderId) {
  store.setState({ activeOrderId: orderId });
  location.hash = `#/tracking/${orderId}`;
}
