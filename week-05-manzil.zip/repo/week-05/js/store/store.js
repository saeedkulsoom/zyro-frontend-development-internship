// store.js — a small hand-rolled Context/Redux-style store: single source of
// truth + subscribe/notify, since this project has no build step for a real
// state library. Holds every piece of shared state the task requires.
function createStore(initialState) {
  let state = initialState;
  const listeners = new Set();

  return {
    getState: () => state,
    setState(patch) {
      state = typeof patch === "function" ? patch(state) : { ...state, ...patch };
      listeners.forEach((fn) => fn(state));
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    }
  };
}

export const store = createStore({
  authenticatedUser: null,      // { id, name, role }
  userRole: null,                // "business" | "rider" | "customer"
  orders: [],
  activeOrderId: null,           // order currently open on the tracking page
  notifications: [],
  riders: [],
  loading: { orders: false, notifications: false, action: false },
  slow: { orders: false },       // true once a request has taken longer than config.mockSlowMs
  errors: { orders: null, notifications: null, action: null },
  page: 1,
  pageSize: 5,
  filters: { query: "", status: "", rider: "", date: "" }
});

export const selectors = {
  isLoggedIn: (s) => !!s.authenticatedUser,
  unreadCount: (s) => s.notifications.filter((n) => !n.read).length,
  activeOrder: (s) => s.orders.find((o) => o.id === s.activeOrderId) || null,
  visibleOrders(s) {
    const { query, status, rider, date } = s.filters;
    const q = query.trim().toLowerCase();
    let list = s.orders.filter((o) => {
      const matchesQ = !q || o.id.toLowerCase().includes(q) || o.customer.toLowerCase().includes(q);
      const matchesStatus = !status || o.status === status;
      const matchesRider = !rider || o.riderId === rider;
      const matchesDate = !date || o.date === date;
      return matchesQ && matchesStatus && matchesRider && matchesDate;
    });
    if (s.userRole === "customer" && s.authenticatedUser) {
      list = list.filter((o) => o.customer === s.authenticatedUser.name);
    }
    if (s.userRole === "rider" && s.authenticatedUser) {
      list = list.filter((o) => o.riderId === s.authenticatedUser.id);
    }
    return list;
  },
  paginated(s) {
    const all = selectors.visibleOrders(s);
    const start = (s.page - 1) * s.pageSize;
    return { items: all.slice(start, start + s.pageSize), total: all.length, page: s.page, pageSize: s.pageSize };
  }
};

export const permissions = {
  canCreateOrder: (role) => role === "business",
  canEditOrder: (role) => role === "business",
  canAssignRider: (role) => role === "business",
  canCancelOrder: (role) => role === "business",
  canAcceptDelivery: (role) => role === "rider",
  canUpdateDeliveryStatus: (role) => role === "rider",
  canTrackOrder: () => true
};
