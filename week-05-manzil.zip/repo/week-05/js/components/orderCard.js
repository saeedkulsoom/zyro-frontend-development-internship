import { STATUS_META } from "../utils/format.js";

export function renderOrderCard(order, { onOpen }) {
  const meta = STATUS_META[order.status] || { label: order.status, cls: "pending" };
  const el = document.createElement("div");
  el.className = "order-card";
  el.innerHTML = `
    <div class="row1"><span class="oid">${order.id}</span><span class="pill ${meta.cls}">${meta.label}</span></div>
    <div class="cust">${order.customer}</div>
    <div class="route">${order.pickup} → ${order.delivery}</div>
  `;
  el.addEventListener("click", () => onOpen(order.id));
  return el;
}
