export function renderPagination({ page, pageSize, total }, onChange) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const el = document.createElement("div");
  el.className = "pagination";
  el.innerHTML = `
    <button class="btn ghost" id="prevPage" ${page <= 1 ? "disabled" : ""}>Previous</button>
    <span class="page-indicator">Page ${page} of ${totalPages} · ${total} order${total === 1 ? "" : "s"}</span>
    <button class="btn ghost" id="nextPage" ${page >= totalPages ? "disabled" : ""}>Next</button>
  `;
  el.querySelector("#prevPage").addEventListener("click", () => onChange(Math.max(1, page - 1)));
  el.querySelector("#nextPage").addEventListener("click", () => onChange(Math.min(totalPages, page + 1)));
  return el;
}
