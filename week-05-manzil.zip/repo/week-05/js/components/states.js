// states.js — task requirement #12: clear UI for initial loading, slow
// requests, failed requests, empty results, and unauthorized access.
export function loadingState(slow) {
  const el = document.createElement("div");
  el.className = "state-box";
  el.innerHTML = `<div class="spinner"></div><p>${slow ? "Still loading — the mock network is being slow…" : "Loading…"}</p>`;
  return el;
}

export function errorState(message, onRetry) {
  const el = document.createElement("div");
  el.className = "state-box error";
  el.innerHTML = `<p>⚠ ${message || "Something went wrong."}</p><button class="btn">Retry</button>`;
  el.querySelector("button").addEventListener("click", onRetry);
  return el;
}

export function emptyState(message) {
  const el = document.createElement("div");
  el.className = "state-box";
  el.innerHTML = `<p>${message || "No results."}</p>`;
  return el;
}

export function unauthorizedState(message) {
  const el = document.createElement("div");
  el.className = "state-box error";
  el.innerHTML = `<p>🔒 ${message || "You don't have permission to view this."}</p>`;
  return el;
}
