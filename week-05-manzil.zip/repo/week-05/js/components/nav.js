import { store, selectors } from "../store/store.js";
import { markNotificationRead, logout } from "../store/actions.js";
import { timeAgo } from "../utils/format.js";

export function renderNav() {
  const s = store.getState();
  const unread = selectors.unreadCount(s);
  const wrap = document.createElement("div");
  wrap.innerHTML = `
    <nav>
      <div class="logo"><span class="dot"></span>Manzil</div>
      <div class="nav-right">
        ${s.authenticatedUser ? `<span class="who">${s.authenticatedUser.name} · ${s.userRole}</span>` : ""}
        <div class="bell-wrap">
          <div class="bell" id="bellBtn" role="button" tabindex="0" aria-label="Notifications">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            ${unread ? `<span class="badge">${unread}</span>` : ""}
          </div>
          <div class="notif-panel" id="notifPanel">
            <header>Notifications</header>
            <div>
              ${s.notifications.length ? s.notifications.slice(0, 8).map((n) => `
                <div class="notif-item ${n.read ? "read" : ""}" data-id="${n.id}">
                  <div class="notif-dot"></div>
                  <div><div>${n.text}</div><div class="t">${timeAgo(n.time)}</div></div>
                </div>`).join("") : `<div class="notif-item"><div>No notifications yet.</div></div>`}
            </div>
          </div>
        </div>
        ${s.authenticatedUser ? `<button class="btn ghost" id="logoutBtn">Log out</button>` : ""}
      </div>
    </nav>`;

  const bell = wrap.querySelector("#bellBtn");
  const panel = wrap.querySelector("#notifPanel");
  bell.addEventListener("click", () => panel.classList.toggle("open"));
  wrap.querySelectorAll(".notif-item[data-id]").forEach((el) => {
    el.addEventListener("click", () => markNotificationRead(el.dataset.id));
  });
  const logoutBtn = wrap.querySelector("#logoutBtn");
  if (logoutBtn) logoutBtn.addEventListener("click", () => { logout(); location.hash = "#/login"; });

  document.addEventListener("click", (e) => {
    if (!wrap.contains(e.target)) panel.classList.remove("open");
  });

  return wrap.firstElementChild;
}
