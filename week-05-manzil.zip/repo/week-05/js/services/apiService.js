// apiService.js — the single API/service layer the app talks to (task requirement #3).
// Components/pages never call mockApi.js directly, and never fetch() directly.
// Swapping mockApi for real fetch() calls against config.apiBaseUrl later only
// requires editing this file.
import { mockApi } from "../api/mockApi.js";

export const apiService = {
  login: (name) => mockApi.login(name),
  getOrders: () => mockApi.getOrders(),
  createOrder: (payload) => mockApi.createOrder(payload),
  updateOrder: (id, patch) => mockApi.updateOrder(id, patch),
  assignRider: (id, riderId) => mockApi.assignRider(id, riderId),
  updateDeliveryStatus: (id, status) => mockApi.updateDeliveryStatus(id, status),
  getNotifications: () => mockApi.getNotifications(),
  markNotificationRead: (id) => mockApi.markNotificationRead(id),
  getRiders: () => mockApi.getRiders()
};
