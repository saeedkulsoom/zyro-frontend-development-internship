// config.js — single place the rest of the app reads configuration from.
// Never hardcode secrets/API URLs elsewhere; always import from here.
const env = window.__ENV__ || {};

export const config = {
  apiBaseUrl: env.API_BASE_URL || "/api",
  mockDelayMs: env.MOCK_DELAY_MS ?? 700,
  mockSlowMs: env.MOCK_SLOW_MS ?? 1500,
  mockFailureRate: env.MOCK_FAILURE_RATE ?? 0.1,
  realtimeIntervalMs: env.REALTIME_INTERVAL_MS ?? 4500
};
