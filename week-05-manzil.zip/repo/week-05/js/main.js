import "./env.js";
import { store, selectors } from "./store/store.js";
import { startLiveUpdates } from "./realtime/liveUpdates.js";
import { config } from "./config.js";
import { renderNav } from "./components/nav.js";
import { renderAuthPage } from "./pages/auth.js";
import { renderDashboard } from "./pages/dashboard.js";
import { renderTracking } from "./pages/tracking.js";

const root = document.getElementById("app");

function currentRoute() {
  const hash = location.hash || "#/login";
  const [, path, param] = hash.match(/^#\/(\w+)(?:\/(.+))?$/) || [];
  return { path: path || "login", param };
}

function render() {
  const s = store.getState();
  const { path, param } = currentRoute();

  root.innerHTML = "";
  if (!selectors.isLoggedIn(s)) {
    if (path !== "login") location.hash = "#/login";
    root.appendChild(renderAuthPage());
    return;
  }

  root.appendChild(renderNav());
  const main = document.createElement("main");
  if (path === "tracking" && param) {
    main.appendChild(renderTracking(param));
  } else {
    main.appendChild(renderDashboard());
  }
  root.appendChild(main);
}

window.addEventListener("hashchange", render);
store.subscribe(render);

if (!location.hash) location.hash = "#/login";
render();
startLiveUpdates(config.realtimeIntervalMs);
