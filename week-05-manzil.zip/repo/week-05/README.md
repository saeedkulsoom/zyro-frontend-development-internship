# Week 5 — Advanced Platform Integration & Real-Time Operations

**Manzil** — Local Delivery & Logistics Management Platform

## How to run
No build step. Just serve the folder (opening `index.html` directly also works for the UI, though ES modules load more reliably from a local server):

```bash
cd week-05
npx serve .
# or: python3 -m http.server
```

Sign in as one of the three demo accounts shown on the login screen — each maps to a different role.

## Architecture

```
week-05/
├── index.html
├── .env.example
├── css/style.css
└── js/
    ├── env.js            # stands in for a .env file (see below)
    ├── config.js         # single place the app reads config from
    ├── main.js           # bootstrap + hash router (#/login, #/dashboard, #/tracking/:id)
    ├── api/
    │   └── mockApi.js    # in-memory mock backend: data, simulated latency & failures
    ├── services/
    │   └── apiService.js # central API/service layer — the only thing pages call
    ├── store/
    │   ├── store.js      # shared state + pub/sub + selectors + role permissions
    │   └── actions.js    # every API call, loading/error/slow handling, optimistic updates
    ├── realtime/
    │   └── liveUpdates.js# simulated real-time engine (interval-based "socket")
    ├── utils/
    │   ├── validation.js
    │   └── format.js
    ├── components/       # nav/notifications, order card, pagination, state boxes
    └── pages/            # auth (login), dashboard (orders), tracking (live delivery)
```

## API integration
`services/apiService.js` is the single service layer every page calls — no component talks to `api/mockApi.js` directly. It exposes `login`, `getOrders`, `createOrder`, `updateOrder`, `assignRider`, `updateDeliveryStatus`, `getNotifications`, `markNotificationRead`, `getRiders`. Swapping the mock for a real backend means editing this one file.

`api/mockApi.js` simulates a REST API: in-memory data, ~700ms latency, and a random ~12% failure rate so the loading/error/retry UI has something real to react to.

## State management
`store/store.js` is a small hand-rolled store (subscribe/notify), since the project has no bundler for React Context/Redux/Zustand. It holds: authenticated user, user role, orders, active order, notifications, riders, loading flags, slow-request flags, API errors, pagination, and filters. `store/actions.js` is the only place that mutates it.

## Real-time delivery updates
`realtime/liveUpdates.js` ticks every 4.5s and randomly advances one active order one step through `pending → accepted → picked → transit → delivered`, pushing the update straight into the store. Any page subscribed to the store (dashboard, tracking, the notification bell) reflects it immediately with no page refresh. Swapping this for a real WebSocket/SSE feed only means replacing `tick()` — the store side stays the same.

## Role-based access
Three demo accounts: **Ayesha Noor** (business — create/edit/assign/cancel orders), **Bilal Khan** (rider — accept/update only their own assigned deliveries), **Hina Yousaf** (customer — view/track only their own orders). `store/store.js`'s `permissions` object gates every action; the tracking page also shows an unauthorized state if a role tries to open an order it doesn't own.

## Optimistic UI
Accepting a delivery, advancing delivery status, and marking a notification read all update the store immediately and roll back with an error if the mock request fails.

## Search, filters & pagination
The dashboard supports search (Order ID or customer), status filter, rider filter, date filter — all combinable, with a clear-filters button — plus pagination (5 per page) with previous/next controls and an empty-state message.

## Environment configuration
`js/env.js` plays the role a `.env` file would in a bundled app; see `.env.example` for what each value means. No credentials or secrets live in source — the mock API needs none, but the pattern is in place for when a real `API_BASE_URL` is added.

## New in Week 5
- Reorganized into components / pages / services / store / realtime / utils / api
- Central API service layer with a mock REST backend (latency + simulated failures)
- Shared state management (custom store) for user, role, orders, active delivery, notifications, loading, errors
- Role-based protected actions for business / rider / customer
- Simulated real-time delivery updates, reflected live on the tracking screen
- Optimistic UI for accept delivery, status updates, and marking notifications read
- Advanced search + filters (status, rider, date, combinable, clear filters)
- Pagination with loading / empty states
- Loading, slow-request, error+retry, and unauthorized states throughout
- Form validation on order creation
- `.env.example` + `js/env.js` for configuration

## Screenshots
_Add screenshots of the login screen, dashboard (with filters), and tracking page here before submitting._
